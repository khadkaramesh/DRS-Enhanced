/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.drsinitial.controller;

/**
 *
 * @author khadk
 */
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;
import javafx.stage.FileChooser;

public class DepartmentController {

    @FXML
    private ChoiceBox<String> departmentTypeChoiceBox;

    @FXML
    private ChoiceBox<String> disasterChoiceBox;

    @FXML
    private Button submitButton;

    @FXML
    private Button backButton1;

    @FXML
    public void initialize() {
        // Initialize the department choices
        departmentTypeChoiceBox.getItems().addAll("Fire", "Transport", "Water", "Hospital", "Government", "Others");

        // Initialize the disaster type choices
        disasterChoiceBox.getItems().addAll("Fire", "Hurricane", "Earthquake", "Flood", "Others");

        // Optionally set default selections
        departmentTypeChoiceBox.setValue("Fire"); // Set a default value
        disasterChoiceBox.setValue("Fire"); // Set a default value
    }

    @FXML
    private void handleSubmit(ActionEvent event) {
        // Validate if a choice is selected
        if (departmentTypeChoiceBox.getValue() == null) {
            showAlert("Error", "Please select a department type.");
            return;
        }
        if (disasterChoiceBox.getValue() == null) {
            showAlert("Error", "Please select a disaster type.");
            return;
        }

        // Retrieve the selected values
        String departmentType = departmentTypeChoiceBox.getValue();
        String disasterType = disasterChoiceBox.getValue();

        // Show the selected values (example)
        showAlert("Information", "Department: " + departmentType + "\nDisaster Type: " + disasterType);

        // Additional form processing can be added here
        // Show success message
        showAlert("Success", "Report submitted successfully!");

        // Optionally navigate to another page or perform additional actions
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            // Load the previous page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/LoadForCoordinationPage.fxml")); // Update to correct FXML
            Parent previousPage = loader.load();

            // Set the scene
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(previousPage));
            stage.setTitle("Previous Page");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to navigate to the previous page.");
        }
    }

    // Helper method to show alerts
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
