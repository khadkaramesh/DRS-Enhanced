package com.mycompany.drsinitial.controller;

/**
 *
 * @author khadk
 */
import com.mycompany.drsinitial.Database.DatabaseHelper;
import com.mycompany.drsinitial.model.User;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ChoiceBox;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class RegisterController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private PasswordField confirmPasswordField;

    @FXML
    private TextField dobField;

    @FXML
    private TextField phoneNumberField;

    @FXML
    private TextField addressField;

    @FXML
    private ChoiceBox<String> userRoleField; // Changed to ChoiceBox

    private DatabaseHelper dbHelper;

    @FXML
    private void initialize() {
        userRoleField.getItems().addAll("Admin", "Incident Manager", "Assessment Team", "Resource Manager", "Departmental Coordination Manager", "Other"); // Populate the ChoiceBox
    }

    @FXML
    private void handleRegister() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();
        String dob = dobField.getText();
        String phoneNumber = phoneNumberField.getText();
        String address = addressField.getText();
        String userRole = userRoleField.getValue(); // Get selected role

        if (validateInputs(username, password, confirmPassword, dob, phoneNumber, address, userRole)) {
            try {
                User newUser = new User(username, password, dob, phoneNumber, address, userRole);
                dbHelper = new DatabaseHelper();
                dbHelper.addUser(newUser); // Add the user to the database
                dbHelper.close();

                showAlert("Success", "User registered successfully!");
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
                showAlert("Registration Failed", "An error occurred while registering the user: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleHome(ActionEvent event) {
        try {
            // Load the homepage FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/HomePage.fxml"));
            Parent homePage = loader.load();

            // Get the current stage
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(homePage));
            stage.setTitle("Homepage");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load homepage.");
        }
    }

    private boolean validateInputs(String username, String password, String confirmPassword, String dob, String phoneNumber, String address, String userRole) {
        if (!password.equals(confirmPassword)) {
            showAlert("Registration Failed", "Passwords do not match.");
            return false;
        }

        if (username.isEmpty() || password.isEmpty() || dob.isEmpty() || phoneNumber.isEmpty() || address.isEmpty() || userRole == null) {
            showAlert("Registration Failed", "Please fill in all fields.");
            return false;
        }

        if (username.length() < 5) {
            showAlert("Registration Failed", "Username must be at least 5 characters long.");
            return false;
        }

        if (password.length() < 8) {
            showAlert("Registration Failed", "Password must be at least 8 characters long.");
            return false;
        }

        if (!isValidDate(dob)) {
            showAlert("Registration Failed", "Date of Birth must be in the format YYYY-MM-DD.");
            return false;
        }

        if (!isValidPhoneNumber(phoneNumber)) {
            showAlert("Registration Failed", "Phone number must be in the format (123) 456-7890.");
            return false;
        }

        if (address.length() < 10) {
            showAlert("Registration Failed", "Address must be at least 10 characters long.");
            return false;
        }

        if (userRole == null || userRole.isEmpty()) {
            showAlert("Registration Failed", "Please select a user role.");
            return false;
        }

        return true;
    }

    private boolean isValidDate(String date) {
        // Simple date validation logic; adapt to your specific needs
        return date.matches("\\d{4}-\\d{2}-\\d{2}");
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        // Simple phone number validation logic; adapt to your specific needs
        return phoneNumber.matches("\\d{10}");
    }

    private void clearFields() {
        usernameField.clear();
        passwordField.clear();
        confirmPasswordField.clear();
        dobField.clear();
        phoneNumberField.clear();
        addressField.clear();
        userRoleField.setValue(null); // Clear ChoiceBox selection
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
