/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.drsinitial.model;

/**
 *
 * @author khadk
 */

public class Alert {
    private int disasterID;
    private int alertID;
    private String message;
    private String dateTime;

    public Alert(int disasterID, int alertID, String message, String dateTime) {
        this.disasterID = disasterID;
        this.alertID = alertID;
        this.message = message;
        this.dateTime = dateTime;
    }

    public int getDisasterID() {
        return disasterID;
    }

    public int getAlertID() {
        return alertID;
    }

    public String getMessage() {
        return message;
    }

    public String getDateTime() {
        return dateTime;
    }
}

