package com.mycompany.drsinitial.controller;

/**
 *
 * @author khadk
 */
import com.mycompany.drsinitial.Database.DatabaseHelper;
import com.mycompany.drsinitial.model.DisasterReport;
import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.event.ActionEvent;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

public class LoadDisastersController {

    @FXML
    private TableView<DisasterReport> disasterTableView;

    @FXML
    private TableColumn<DisasterReport, Integer> disasterIdColumn;

    @FXML
    private TableColumn<DisasterReport, String> disasterTypeColumn;

    @FXML
    private TableColumn<DisasterReport, String> locationColumn;

    @FXML
    private TableColumn<DisasterReport, String> severityColumn;

    @FXML
    private TableColumn<DisasterReport, LocalDate> reportDateColumn;

    @FXML
    private Button updateSelectedButton;

    @FXML
    private Button backToAssessment;

    @FXML
    private Label titleLabel;

    @FXML
    public void initialize() {
        disasterIdColumn.setCellValueFactory(new PropertyValueFactory<>("disasterId"));
        disasterTypeColumn.setCellValueFactory(new PropertyValueFactory<>("disasterType"));
        locationColumn.setCellValueFactory(new PropertyValueFactory<>("location"));
        severityColumn.setCellValueFactory(new PropertyValueFactory<>("severity"));
        reportDateColumn.setCellValueFactory(new PropertyValueFactory<>("reportDate"));

        loadDisasterReports();
    }

    private void loadDisasterReports() {
        try {
            DatabaseHelper dbHelper = new DatabaseHelper();
            List<DisasterReport> reports = dbHelper.getDisasterReports();
            ObservableList<DisasterReport> observableReports = FXCollections.observableArrayList(reports);
            disasterTableView.setItems(observableReports);
        } catch (SQLException e) {
            showAlert("Error", "Failed to load disaster reports from the database.");
            e.printStackTrace();
        }
    }

    @FXML
    private void handleUpdateSelected(ActionEvent event) {
        // Implement the logic to update the selected report
        // Implement navigation logic to go back to the dashboard
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/AssessmentFormPage.fxml"));
            Parent homePage = loader.load();

            // Get the current stage
            Stage stage = (Stage) backToAssessment.getScene().getWindow();
            stage.setScene(new Scene(homePage));
            stage.setTitle("Homepage");
        } catch (IOException e) {
            showAlert("Error", "Failed to load assessmentform.");
        }
    }

    @FXML
    private void backToAssessment(ActionEvent event) {
        // Implement navigation logic to go back to the dashboard
        try {
            // Load the AssessmentPage FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/AssessmentPage.fxml"));
            Parent homePage = loader.load();

            // Get the current stage
            Stage stage = (Stage) backToAssessment.getScene().getWindow();
            stage.setScene(new Scene(homePage));
            stage.setTitle("Homepage");
        } catch (IOException e) {
            showAlert("Error", "Failed to load homepage.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
