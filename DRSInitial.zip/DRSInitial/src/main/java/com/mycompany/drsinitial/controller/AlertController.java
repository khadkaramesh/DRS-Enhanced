package com.mycompany.drsinitial.controller;

/**
 *
 * @author khadk
 */
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import com.mycompany.drsinitial.Database.DatabaseHelper;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AlertController {

    @FXML
    private Button addAlertButton;

    @FXML
    private Button updateSelectedButton;

    @FXML
    private Button deleteSelectedButton;

    @FXML
    private Button backToDashboardButton;

    @FXML
    private TextField alertIDField;

    @FXML
    private TextField disasterIDField;

    @FXML
    private TextField messageField;

    @FXML
    private CheckBox checkBox1;

    @FXML
    private CheckBox checkBox2;

    @FXML
    private CheckBox checkBox3;

    @FXML
    private CheckBox checkBox4;

    @FXML
    private GridPane gridPane;

    private DatabaseHelper databaseHelper;

    public void initialize() {
        try {
            // Initialize the DatabaseHelper manually if not injected
            databaseHelper = new DatabaseHelper(); // Ensure this matches how you configure your DatabaseHelper

            // Initialize the GridPane with data
            populateGridPane();
        } catch (SQLException ex) {
            Logger.getLogger(AlertController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void populateGridPane() {
        // Clear existing content
        gridPane.getChildren().clear();

        // Add column headers
        gridPane.add(new Label("Alert ID"), 0, 0);
        gridPane.add(new Label("Disaster ID"), 1, 0);
        gridPane.add(new Label("Message"), 2, 0);

        // Connect to the database and fetch alert data
        try (Connection conn = databaseHelper.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery("SELECT * FROM alerts")) {

            int row = 2; // Start from the second row since the first row contains headers

            while (rs.next()) {
                int alertID = rs.getInt("alert_id");
                int disasterID = rs.getInt("disaster_id");
                String message = rs.getString("message");

                // Create labels for each piece of data
                Label alertIDLabel = new Label(String.valueOf(alertID));
                Label disasterIDLabel = new Label(String.valueOf(disasterID));
                Label messageLabel = new Label(message);

                // Add labels to the GridPane
                gridPane.add(alertIDLabel, 0, row);
                gridPane.add(disasterIDLabel, 1, row);
                gridPane.add(messageLabel, 2, row);

                row++;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Database Error", "Failed to fetch alerts.");
        }
    }

    @FXML
    private void handleAddAlert(ActionEvent event) {
        try {
            // Load the AddAlert FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/AddAlert.fxml"));
            Parent homePage = loader.load();

            // Get the current stage
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(homePage));
            stage.setTitle("Add Alert");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Error", "Failed to load Add Alert page.");
        }
    }

    @FXML
    private void handleUpdateSelected(ActionEvent event) {
        String alertID = alertIDField.getText();
        String disasterID = disasterIDField.getText();
        String message = messageField.getText();

        if (alertID.isEmpty() || disasterID.isEmpty() || message.isEmpty()) {
            showAlert(AlertType.ERROR, "Form Error!", "Please enter all fields");
            return;
        }

        // Update alert logic here (e.g., updating the database record)
        showAlert(AlertType.INFORMATION, "Success", "Alert updated successfully!");
    }

    @FXML
    private void handleDeleteSelected(ActionEvent event) {
        String alertID = alertIDField.getText();

        if (alertID.isEmpty()) {
            showAlert(AlertType.ERROR, "Form Error!", "Please enter the Alert ID to delete");
            return;
        }

        // Delete alert logic here (e.g., deleting from the database)
        showAlert(AlertType.INFORMATION, "Success", "Alert deleted successfully!");
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        try {
            // Load the DashboardPage FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/DashboardPage.fxml"));
            Parent homePage = loader.load();

            // Get the current stage
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(homePage));
            stage.setTitle("Dashboard");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Error", "Failed to load Dashboard page.");
        }
    }

    private void showAlert(AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
