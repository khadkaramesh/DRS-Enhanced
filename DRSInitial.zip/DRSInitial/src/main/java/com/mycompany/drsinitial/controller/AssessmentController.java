/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.drsinitial.controller;

/**
 *
 * @author khadk
 */
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import java.io.IOException;

public class AssessmentController {

    @FXML
    private Button logout;

    @FXML
    private Button assessment;

    @FXML
    private Button loadDisaster;

    // Handle logout action
    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            // Load the login page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/Login.fxml"));
            Parent loginPage = loader.load();

            // Set the new scene
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene loginScene = new Scene(loginPage);
            stage.setScene(loginScene);
            stage.setTitle("Login Page");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load login page.");
        }
    }

    // Handle assessment action
    @FXML
    private void handleAssessment(ActionEvent event) {
        try {
            // Load the assessment page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/AssessmentPage.fxml"));
            Parent assessmentPage = loader.load();

            // Set the new scene
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene assessmentScene = new Scene(assessmentPage);
            stage.setScene(assessmentScene);
            stage.setTitle("Assessment Page");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load assessment page.");
        }
    }

    // Handle load disaster action
    @FXML
    private void loadDisaster(ActionEvent event) {
        try {
            // Load the disaster page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/LoadDisasters1.fxml"));
            Parent disasterPage = loader.load();

            // Set the new scene
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene disasterScene = new Scene(disasterPage);
            stage.setScene(disasterScene);
            stage.setTitle("Disaster Management Page");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load disaster page.");
        }
    }

    // Show alert dialog
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
