/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.drsinitial.Database;

/**
 *
 * @author khadk
 */
import java.sql.Connection;
import java.sql.SQLException;

public class DatabaseSetupTest {
    public static void main(String[] args) {
        try {
            // Test the database connection
            Connection connection = DatabaseSetup.getConnection();
            
            // Print success message
            System.out.println("Database connection successful!");

            // Close the connection
            connection.close();
        } catch (SQLException e) {
            // Print error message
            System.err.println("Database connection failed!");
            e.printStackTrace();
        }
    }
}
