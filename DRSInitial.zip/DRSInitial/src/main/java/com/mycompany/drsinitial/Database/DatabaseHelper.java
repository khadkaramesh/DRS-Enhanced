package com.mycompany.drsinitial.Database;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author khadk
*/

import com.mycompany.drsinitial.model.DisasterReport;
import com.mycompany.drsinitial.model.User;
import com.mycompany.drsinitial.model.Alert;
import com.mycompany.drsinitial.model.DisasterAssessment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper {

    private static final String URL = "jdbc:mysql://localhost:3306/drs_initial";
    private static final String USER = "root";
    private static final String PASSWORD = "Ramesh@123"; // Replace with your actual password

    private Connection connection;

    public DatabaseHelper() throws SQLException {
        connection = DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // Method to insert a disaster report into the database
    public void insertDisasterReport(DisasterReport report, byte[] imageBytes) throws SQLException {
        String sql = "INSERT INTO disaster_reports (disaster_id, disaster_type, location, severity, description, reported_by, report_date, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, report.getDisasterId());
            statement.setString(2, report.getDisasterType());
            statement.setString(3, report.getLocation());
            statement.setString(4, report.getSeverity());
            statement.setString(5, report.getDescription());
            statement.setString(6, report.getReportedBy());
            statement.setDate(7, java.sql.Date.valueOf(report.getReportDate()));
            statement.setBytes(8, report.getImage());  // Set the image data as a byte array

            statement.executeUpdate();
        }
    }

    // Method to insert an alert into the database
    public void insertAlert(Alert alert) throws SQLException {
        String sql = "INSERT INTO alerts (alert_id, disaster_id, message, date_time) VALUES (?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, alert.getAlertID());
            statement.setInt(2, alert.getDisasterID());
            statement.setString(3, alert.getMessage());
            statement.setString(4, alert.getDateTime());

            statement.executeUpdate();
        }
    }

    // Method to retrieve an alert by its ID from the database
    public Alert getAlertById(int alertId) throws SQLException {
        String query = "SELECT alert_id, disaster_id, message, date_time FROM alerts WHERE alert_id = ?";
        Alert alert = null;

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, alertId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int disasterId = rs.getInt("disaster_id");
                String message = rs.getString("message");
                String dateTime = rs.getString("date_time");
                alert = new Alert(disasterId, alertId, message, dateTime);
            }
        }

        return alert;
    }

    // Method to update an alert in the database
    public void updateAlert(Alert alert) throws SQLException {
        String sql = "UPDATE alerts SET disaster_id = ?, message = ?, date_time = ? WHERE alert_id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, alert.getDisasterID());
            statement.setString(2, alert.getMessage());
            statement.setString(3, alert.getDateTime());
            statement.setInt(4, alert.getAlertID());

            statement.executeUpdate();
        }
    }

    // Method to delete an alert from the database
    public void deleteAlert(int alertId) throws SQLException {
        String sql = "DELETE FROM alerts WHERE alert_id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, alertId);
            statement.executeUpdate();
        }
    }

    // Method to retrieve a user by username from the database
    public User getUserByUsername(String username) {
        User user = null;
        String query = "SELECT username, password, userrole FROM users WHERE username = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String retrievedUsername = rs.getString("username");
                String retrievedPassword = rs.getString("password");
                String retrievedUserrole = rs.getString("userrole");
                user = new User(retrievedUsername, retrievedPassword, retrievedUserrole);
            }
        } catch (SQLException e) {
            e.printStackTrace();  // Consider using a logging framework
        }

        return user;
    }

    // Method to add a new user to the database
    public void addUser(User user) throws SQLException {
        String sql = "INSERT INTO users (username, password, dob, phone_number, address, userrole) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, user.getUsername());
            statement.setString(2, user.getPassword()); // Consider hashing the password before storing
            statement.setString(3, user.getDob());
            statement.setString(4, user.getPhoneNumber());
            statement.setString(5, user.getAddress());
            statement.setString(6, user.getUserRole());

            statement.executeUpdate();
        }
    }

    // Method to update a user's password in the database
    public void updateUserPassword(String username, String newPassword) throws SQLException {
        String sql = "UPDATE users SET password = ? WHERE username = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, newPassword); // Consider hashing the new password
            statement.setString(2, username);
            statement.executeUpdate();
        }
    }

    // Method to delete a user from the database
    public void deleteUser(String username) throws SQLException {
        String sql = "DELETE FROM users WHERE username = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);
            statement.executeUpdate();
        }
    }

    // Example method to fetch disaster reports
    public List<DisasterReport> getDisasterReports() throws SQLException {
        List<DisasterReport> reports = new ArrayList<>();
        String query = "SELECT * FROM disaster_reports";

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                int disasterId = rs.getInt("disaster_id");
                String disasterType = rs.getString("disaster_type");
                String location = rs.getString("location");
                String severity = rs.getString("severity");
                String description = rs.getString("description");
                String reportedBy = rs.getString("reported_by");

                LocalDate reportDate = null;
                if (rs.getDate("report_date") != null) {
                    reportDate = rs.getDate("report_date").toLocalDate();
                }

                byte[] image = rs.getBytes("image");

                DisasterReport report = new DisasterReport(disasterId, disasterType, location, severity, description, reportedBy, reportDate, image);
                reports.add(report);
            }
        }

        return reports;
    }

    // Method to insert a disaster assessment into the database
    public void insertDisasterAssessment(DisasterAssessment assessment) throws SQLException {
        String sql = "INSERT INTO disaster_assessments (disaster_id, assessment, response, assessment_date) VALUES (?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, assessment.getDisasterId());
            statement.setString(2, assessment.getAssessment());
            statement.setString(3, assessment.getResponse());
            statement.setTimestamp(4, Timestamp.valueOf(assessment.getAssessmentDate())); // Ensure assessmentDate is of type LocalDateTime or Timestamp

            statement.executeUpdate();
        }
    }

    // Method to check if a disasterId exists in the disaster_reports table
    public boolean disasterIdExists(int disasterId) throws SQLException {
        String query = "SELECT COUNT(*) FROM disaster_reports WHERE disaster_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, disasterId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0; // Return true if disasterId exists
                }
            }
        }
        return false; // If no matching record is found, return false
    }

    // Method to close the database connection
    public void close() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    public Connection getConnection() throws SQLException {
        return connection; // Use the existing connection
    }
}
