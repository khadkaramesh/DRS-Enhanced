package com.mycompany.drsinitial.controller;

/**
 *
 * @author khadk
 */
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.Alert;
import java.io.IOException;
import javafx.scene.Node;

public class DashboardController {

    @FXML
    private Button alerts;

    @FXML
    private Button resources;

    @FXML
    private Button logout;

    @FXML
    private Button trackincident;

    @FXML
    private Button assessment;

    @FXML
    private Button reports;

    @FXML
    private Button communicate;

    @FXML
    private Button addUser;

    @FXML
    private TextArea lalertList;

    @FXML
    private TextArea incidentSummary;

    @FXML
    private TextArea resourceStatus;

    @FXML
    private TextArea publicInformation;

    // Method to load different views
    private void loadView(ActionEvent event, String fxmlFile) {
        try {
            // Load the new FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent view = loader.load();
            Scene newScene = new Scene(view);

            // Get the current stage (window)
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the scene to the new view
            stage.setScene(newScene);
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load the view.");
        }
    }

    // Handle the Logout button click
    @FXML
    private void handleLogout(ActionEvent event) {
        loadView(event, "/com/mycompany/drsinitial/Login.fxml");
    }

    // Handle the Alerts button click
    @FXML
    private void handleAlerts(ActionEvent event) {
        loadView(event, "/com/mycompany/drsinitial/AlertManagement.fxml");
    }

    // Handle the Resources button click
    @FXML
    private void manageResource(ActionEvent event) {
        loadView(event, "/com/mycompany/drsinitial/ResourceManagement.fxml");
    }

    // Handle the Track Incident button click
    @FXML
    private void handleIncidents(ActionEvent event) {
        loadView(event, "/com/mycompany/drsinitial/IncidentTracking.fxml");
    }

    // Handle the Assessment button click
    @FXML
    private void handleAssessment(ActionEvent event) {
        loadView(event, "/com/mycompany/drsinitial/AssessmentPage.fxml");
    }

    // Handle the Reports button click
    @FXML
    private void generateReports(ActionEvent event) {
        loadView(event, "/com/mycompany/drsinitial/Reports.fxml");
    }

    // Handle the Communication button click
    @FXML
    private void departmentalCommunication(ActionEvent event) {
        loadView(event, "/com/mycompany/drsinitial/Communication.fxml");
    }

    // Handle the Add Users button click
    @FXML
    private void handleAddUser(ActionEvent event) {
        loadView(event, "/com/mycompany/drsinitial/RegisterPage.fxml");
    }

    // Display an alert dialog
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
