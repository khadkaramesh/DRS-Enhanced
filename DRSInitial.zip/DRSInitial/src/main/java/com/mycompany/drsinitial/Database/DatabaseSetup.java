package com.mycompany.drsinitial.Database;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author khadk
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DatabaseSetup {

    private static final String URL = "jdbc:mysql://localhost:3306/drs_initial";
    private static final String USER = "root";
    private static final String PASSWORD = "Ramesh@123";

    // Private constructor to prevent instantiation
    private DatabaseSetup() {}

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void insertDisasterReport(int disasterId, String disasterType, String location, String severity,
                                            String description, String reportedBy, String reportDate, byte[] image) {
        String query = "INSERT INTO disaster_reports (disaster_id, disaster_type, location, severity, description, reported_by, report_date, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, disasterId);
            stmt.setString(2, disasterType);
            stmt.setString(3, location);
            stmt.setString(4, severity);
            stmt.setString(5, description);
            stmt.setString(6, reportedBy);
            stmt.setString(7, reportDate);
            stmt.setBytes(8, image);  // Set the image as a byte array

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();  // Or log it using a logging framework
        }
    }
}
