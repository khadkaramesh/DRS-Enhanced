/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.drsinitial.model;

/**
 *
 * @author khadk
 */

import java.time.LocalDateTime;

public class DisasterAssessment {
    private int id;
    private int disasterId;
    private String assessment;
    private String response;
    private LocalDateTime assessmentDate;

    // Constructors
    public DisasterAssessment() {}

    public DisasterAssessment(int disasterId, String assessment, String response, LocalDateTime assessmentDate) {
        this.disasterId = disasterId;
        this.assessment = assessment;
        this.response = response;
        this.assessmentDate = assessmentDate;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDisasterId() {
        return disasterId;
    }

    public void setDisasterId(int disasterId) {
        this.disasterId = disasterId;
    }

    public String getAssessment() {
        return assessment;
    }

    public void setAssessment(String assessment) {
        this.assessment = assessment;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public LocalDateTime getAssessmentDate() {
        return assessmentDate;
    }

    public void setAssessmentDate(LocalDateTime assessmentDate) {
        this.assessmentDate = assessmentDate;
    }
}
