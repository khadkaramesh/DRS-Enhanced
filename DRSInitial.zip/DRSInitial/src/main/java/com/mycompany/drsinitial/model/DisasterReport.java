/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.drsinitial.model;

/**
 *
 * @author khadk
 */

import java.time.LocalDate;

public class DisasterReport {

    private int disasterId;
    private String disasterType;
    private String location;
    private String severity;
    private String description;
    private String reportedBy;
    private LocalDate reportDate;
    private byte[] image;  // Field to store the image

    // Constructor
    public DisasterReport(int disasterId, String disasterType, String location, String severity, String description, String reportedBy, LocalDate reportDate, byte[] imageBytes) {
        this.disasterId = disasterId;
        this.disasterType = disasterType;
        this.location = location;
        this.severity = severity;
        this.description = description;
        this.reportedBy = reportedBy;
        this.reportDate = reportDate;
        this.image = imageBytes;  // Initialize with imageBytes
    }

    // Getters and setters
    public int getDisasterId() {
        return disasterId;
    }

    public void setDisasterId(int disasterId) {
        this.disasterId = disasterId;
    }

    public String getDisasterType() {
        return disasterType;
    }

    public void setDisasterType(String disasterType) {
        this.disasterType = disasterType;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getReportedBy() {
        return reportedBy;
    }

    public void setReportedBy(String reportedBy) {
        this.reportedBy = reportedBy;
    }

    public LocalDate getReportDate() {
        return reportDate;
    }

    public void setReportDate(LocalDate reportDate) {
        this.reportDate = reportDate;
    }

    public byte[] getImage() {  // Getter for the image
        return image;
    }

    public void setImage(byte[] image) {  // Setter for the image
        this.image = image;
    }
}
