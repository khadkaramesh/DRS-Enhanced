package com.mycompany.drsinitial.controller;

/**
 *
 * @author khadk
 */
import com.mycompany.drsinitial.Database.DatabaseHelper;
import com.mycompany.drsinitial.model.User;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.event.ActionEvent;
import javafx.scene.Node;

import java.io.IOException;
import java.sql.SQLException;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button loginButton;

    @FXML
    private ChoiceBox<String> userRole;

    @FXML
    private Button homeButton;

    private DatabaseHelper dbHelper;

    @FXML
    private void initialize() {
        try {
            dbHelper = new DatabaseHelper();
            userRole.getItems().addAll("Admin", "Assessment Team", "Departmental coordination manager", "Incident Manager", "Resource Manager");
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to connect to the database.");
            e.printStackTrace();
        }
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        String role = userRole.getValue();  // Get selected user role

        try {
            User user = dbHelper.getUserByUsername(username);
            if (user != null && user.validate(password)) {
                loadDashboard(role);  // Pass role to the dashboard loading method
            } else {
                showAlert("Login Failed", "Please enter a valid username and password.");
            }
        } catch (Exception e) {
            showAlert("Error", "An unexpected error occurred.");
            e.printStackTrace();
        }
    }

    @FXML
    private void handleHome(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/HomePage.fxml"));
            Parent homePage = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(homePage));
            stage.setTitle("Homepage");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load homepage.");
        }
    }

    // Updated loadDashboard method to handle "Incident Manager" role
    private void loadDashboard(String role) {
        try {
            Parent page;
            FXMLLoader loader;

            if ("Assessment Team".equals(role)) {
                // If the user role is "Assessment Team", load the assessment page
                loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/AssessmentPage.fxml"));
                page = loader.load();
            } else if ("Incident Manager".equals(role)) {
                // Load Incident Management page for Incident Manager
                loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/IncidentManagementPage.fxml"));
                page = loader.load();
            } else if ("Resource Manager".equals(role)) {
                // Load Incident Management page for Incident Manager
                loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/ResourceManagementPage.fxml"));
                page = loader.load();
            } else if ("Departmental coordination manager".equals(role)) {
                // Load Incident Management page for Incident Manager
                loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/CoordinationPage.fxml"));
                page = loader.load();
            } else {
                // Load the default dashboard page for other roles
                loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/DashboardPage.fxml"));
                page = loader.load();
            }

            Scene scene = new Scene(page);
            Stage stage = (Stage) loginButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle(role + " - Disaster Response System");  // Set title based on role
        } catch (IOException e) {
            showAlert("Error", "Failed to load the appropriate page.");
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void close() {
        try {
            if (dbHelper != null) {
                dbHelper.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
