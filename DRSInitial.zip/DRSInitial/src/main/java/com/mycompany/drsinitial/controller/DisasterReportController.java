/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.drsinitial.controller;

/**
 *
 * @author khadk
 */
import com.mycompany.drsinitial.Database.DatabaseHelper;
import com.mycompany.drsinitial.model.DisasterReport;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class DisasterReportController {

    @FXML
    private TextField disasterIDField;
    @FXML
    private ChoiceBox<String> disasterTypeChoiceBox;
    @FXML
    private TextField locationField;
    @FXML
    private ChoiceBox<String> severityChoiceBox;
    @FXML
    private TextField descriptionField;
    @FXML
    private TextField reportedByField;
    @FXML
    private TextField reportDateField;

    @FXML
    private Button submitButton;
    @FXML
    private Button backButton;
    @FXML
    private Button uploadButton;

    @FXML
    private ImageView uploadedImageView;

    private byte[] imageBytes;  // Store the uploaded image as a byte array

    @FXML
    public void initialize() {
        try {
            // Initialize disaster types and severity levels
            disasterTypeChoiceBox.getItems().addAll("Flood", "Earthquake", "Fire", "Storm", "Other");
            severityChoiceBox.getItems().addAll("Low", "Medium", "High", "Critical");
        } catch (Exception e) {
            showAlert("Error", "Failed to initialize choice boxes.");
        }
    }

    @FXML
    private void handleSubmit(ActionEvent event) {
        try {
            byte[] imageBytes = null;
            if (selectedImageFile != null && selectedImageFile.exists()) {
                imageBytes = java.nio.file.Files.readAllBytes(selectedImageFile.toPath());
            }

            // Create DisasterReport object with the image data
            DisasterReport report = new DisasterReport(
                    Integer.parseInt(disasterIDField.getText()),
                    disasterTypeChoiceBox.getValue(),
                    locationField.getText(),
                    severityChoiceBox.getValue(),
                    descriptionField.getText(),
                    reportedByField.getText(),
                    LocalDate.parse(reportDateField.getText()),
                    imageBytes // Pass the image byte array
            );

            // Validate the report
            if (validateReport(report)) {
                // Save the report to the database
                DatabaseHelper dbHelper = new DatabaseHelper();
                dbHelper.insertDisasterReport(report, imageBytes);  // Pass the image bytes along with the report
                showAlert("Success", "Disaster report submitted successfully!");
            } else {
                showAlert("Error", "Please fill in all fields correctly.");
            }
        } catch (NumberFormatException e) {
            showAlert("Error", "Disaster ID must be a number.");
        } catch (DateTimeParseException e) {
            showAlert("Error", "Invalid date format. Please use YYYY-MM-DD.");
        } catch (IOException e) {
            showAlert("Error", "Failed to read the image file.");
        } catch (SQLException e) {
            showAlert("Error", "Database error occurred.");
            e.printStackTrace();  // Log SQL errors
        } catch (Exception e) {
            showAlert("Error", "An unexpected error occurred while submitting the report.");
            e.printStackTrace();  // Log any other unexpected errors
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            // Load the homepage FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/HomePage.fxml"));
            Parent homePage = loader.load();

            // Get the current stage
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(homePage));
            stage.setTitle("Homepage");
        } catch (IOException e) {
            showAlert("Error", "Failed to load homepage.");
        }
    }

    @FXML
    private File selectedImageFile;

    @FXML
    private void handleUpload(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );

        selectedImageFile = fileChooser.showOpenDialog(null);

        if (selectedImageFile != null) {
            uploadedImageView.setImage(new Image(selectedImageFile.toURI().toString()));
            System.out.println("Image uploaded: " + selectedImageFile.getAbsolutePath());
        } else {
            System.out.println("Image upload canceled.");
        }
    }

    private byte[] convertImageToBytes(File imageFile) {
        try (FileInputStream fis = new FileInputStream(imageFile); ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                baos.write(buffer, 0, bytesRead);
            }
            return baos.toByteArray();
        } catch (IOException e) {
            showAlert("Error", "Failed to convert image to byte array.");
            return null;
        }
    }

    private boolean validateReport(DisasterReport report) {
        // Simple validation check
        return report.getDisasterId() > 0
                && report.getDisasterType() != null
                && !report.getLocation().isEmpty()
                && report.getSeverity() != null
                && !report.getDescription().isEmpty()
                && !report.getReportedBy().isEmpty()
                && report.getReportDate() != null
                && report.getImage() != null;  // Ensure image is uploaded
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
