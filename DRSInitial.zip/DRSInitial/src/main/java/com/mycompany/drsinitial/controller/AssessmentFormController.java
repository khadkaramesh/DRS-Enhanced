package com.mycompany.drsinitial.controller;

/**
 *
 * @author khadk
 */

import com.mycompany.drsinitial.Database.DatabaseHelper;
import com.mycompany.drsinitial.model.DisasterAssessment;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class AssessmentFormController {

    @FXML
    private TextField assessmentId;  // Disaster ID

    @FXML
    private TextArea assessmentField;  // Assessment

    @FXML
    private TextArea responseField;  // Response

    @FXML
    private DatePicker assessmentDateField;  // Assessment Date (using DatePicker)

    @FXML
    private Button submitButton;

    @FXML
    private Button homeButton;

    private int disasterId; // Field to store the disaster ID

    // Method to initialize the form with disasterId (if required)
    public void initialize(int disasterId) {
        this.disasterId = disasterId;
        // You can pre-populate fields here if necessary
        assessmentId.setText(String.valueOf(disasterId));
    }

    @FXML
    private void handleSubmit(ActionEvent event) {
        try {
            // Retrieve and validate disaster ID from the text field
            String assessmentIdText = assessmentId.getText().trim();
            if (assessmentIdText == null || assessmentIdText.isEmpty()) {
                showAlert("Error", "Disaster ID cannot be empty.");
                return;
            }

            int disasterId;
            try {
                disasterId = Integer.parseInt(assessmentIdText);  // Retrieve disaster ID
            } catch (NumberFormatException e) {
                showAlert("Error", "Disaster ID must be a valid number. Value provided: " + assessmentIdText);
                return;
            }

            // Validate if the disasterId exists in the database
            DatabaseHelper dbHelper = new DatabaseHelper();
            if (!dbHelper.disasterIdExists(disasterId)) {
                showAlert("Error", "Disaster ID does not exist.");
                return;
            }

            String assessment = assessmentField.getText();  // Retrieve assessment
            String response = responseField.getText();  // Retrieve response

            // Validate if assessment and response fields are not empty
            if (assessment == null || assessment.trim().isEmpty()) {
                showAlert("Error", "Assessment cannot be empty.");
                return;
            }
            if (response == null || response.trim().isEmpty()) {
                showAlert("Error", "Response cannot be empty.");
                return;
            }

            // Get the assessment date from DatePicker
            if (assessmentDateField.getValue() == null) {
                showAlert("Error", "Assessment date must be selected.");
                return;
            }
            LocalDate assessmentDate = assessmentDateField.getValue();

            // Convert LocalDate to LocalDateTime if needed
            LocalDateTime assessmentDateTime = assessmentDate.atStartOfDay();

            // Create a new DisasterAssessment object with the collected data
            DisasterAssessment newAssessment = new DisasterAssessment(disasterId, assessment, response, assessmentDateTime);

            // Insert the new assessment into the database
            dbHelper.insertDisasterAssessment(newAssessment);

            // Show success message
            showAlert("Success", "Assessment submitted successfully!");

            // Navigate back to the previous page
            navigateToPreviousPage();
        } catch (SQLException e) {
            showAlert("Error", "Failed to submit assessment.");
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        navigateToPreviousPage();
    }

    // Navigate back to the previous page
    private void navigateToPreviousPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/LoadDisasters1.fxml"));
            Parent homePage = loader.load();

            Stage stage = (Stage) homeButton.getScene().getWindow();
            stage.setScene(new Scene(homePage));
            stage.setTitle("Disaster Reports");
        } catch (IOException e) {
            showAlert("Error", "Failed to navigate to the previous page.");
            e.printStackTrace();
        }
    }

    // Helper method to show alerts
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
