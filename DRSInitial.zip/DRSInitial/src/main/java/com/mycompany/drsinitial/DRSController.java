package com.mycompany.drsinitial;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;
import com.mycompany.drsinitial.Database.DatabaseHelper;
import java.io.IOException;

public class DRSController {

    @FXML
    private Button viewalart;

    @FXML
    private Button signin;

    @FXML
    private Button disasterreport;

    @FXML
    private TextArea textArea;  // Ensure this matches fx:id in FXML

    private DatabaseHelper databaseHelper;

    @FXML
    private void initialize() throws SQLException {
        // Initialize the database helper
        databaseHelper = new DatabaseHelper();
    }

    @FXML
    private void handleViewAlert(ActionEvent event) {
        // Fetch the alerts from the database and display them in the textArea
        StringBuilder alertsText = new StringBuilder();
        try (Connection conn = databaseHelper.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM alerts")) {

            while (rs.next()) {
//                int alertID = rs.getInt("alert_id");
//                int disasterID = rs.getInt("disaster_id");
                String message = rs.getString("message");
                String dateTime = rs.getString("date_time");

                alertsText.append("Stay Alert: ")
                          .append("\nMessage: ").append(message)
                          .append("\nDate/Time: ").append(dateTime)
                          .append("\n\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (textArea != null) {
            textArea.setText(alertsText.toString());
        } else {
            System.out.println("TextArea is null!");
        }
    }

    @FXML
    private void handleSignIn(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleReportDisaster(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("DisasterReport.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
