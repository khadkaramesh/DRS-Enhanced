package com.mycompany.drsinitial.controller;

/**
 *
 * @author khadk
 */
import com.mycompany.drsinitial.model.Alert;
import com.mycompany.drsinitial.Database.DatabaseHelper;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import java.sql.SQLException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class AddAlertController {

    @FXML
    private TextField disasterIDField;

    @FXML
    private TextField alertIDField;

    @FXML
    private TextField messageField;

    @FXML
    private TextField dateTimeField;

    @FXML
    private Button submitButton;

    @FXML
    private Button backButton;

    private DatabaseHelper databaseHelper;

    public AddAlertController() {
        try {
            databaseHelper = new DatabaseHelper();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Database Error!", "Failed to connect to the database.");
        }
    }

    @FXML
    private void handleSubmit(ActionEvent event) {
        String disasterID = disasterIDField.getText();
        String alertID = alertIDField.getText();
        String message = messageField.getText();
        String dateTime = dateTimeField.getText();

        if (disasterID.isEmpty() || alertID.isEmpty() || message.isEmpty() || dateTime.isEmpty()) {
            showAlert(AlertType.ERROR, "Form Error!", "Please fill in all fields.");
            return;
        }

        Alert alert = new Alert(Integer.parseInt(disasterID), Integer.parseInt(alertID), message, dateTime);

        try {
            databaseHelper.insertAlert(alert);
            showAlert(AlertType.INFORMATION, "Success!", "Alert has been added successfully.");
            clearFields();
        } catch (SQLException e) {
            showAlert(AlertType.ERROR, "Database Error!", "Failed to save alert: " + e.getMessage());
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {

        try {
            // Load the homepage FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/drsinitial/AlertManagement.fxml"));
            Parent homePage = loader.load();

            // Get the current stage
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(homePage));
            stage.setTitle("Homepage");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(AlertType alertType, String title, String message) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void clearFields() {
        disasterIDField.clear();
        alertIDField.clear();
        messageField.clear();
        dateTimeField.clear();
    }
}
