module com.mycompany.drsinitial {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    
    opens com.mycompany.drsinitial to javafx.fxml;
    opens com.mycompany.drsinitial.controller to javafx.fxml;
    exports com.mycompany.drsinitial;
    exports com.mycompany.drsinitial.controller to javafx.fxml;
    opens com.mycompany.drsinitial.Database to javafx.fxml;
    opens com.mycompany.drsinitial.model to javafx.base;
}


